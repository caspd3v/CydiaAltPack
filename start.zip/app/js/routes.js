var routes = [
  {
    path: '/',
    url: './index.html',
    name: 'index',
  }
  ];